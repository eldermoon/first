function varargout = datika(varargin)
% DATIKA MATLAB code for datika.fig
%      DATIKA, by itself, creates a new DATIKA or raises the existing
%      singleton*.
%
%      H = DATIKA returns the handle to a new DATIKA or the handle to
%      the existing singleton*.
%
%      DATIKA('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in DATIKA.M with the given input arguments.
%
%      DATIKA('Property','Value',...) creates a new DATIKA or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before datika_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to datika_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help datika

% Last Modified by GUIDE v2.5 05-Jul-2022 01:23:38

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @datika_OpeningFcn, ...
                   'gui_OutputFcn',  @datika_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before datika is made visible.
function datika_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to datika (see VARARGIN)

% Choose default command line output for datika
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes datika wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = datika_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global allPath
[fileName,pathName]=uigetfile({'*.jpg;*.tif;*.png;*.gif','All Image Files';'*.*','All Files'},'��ѡ��Ҫ��ʾ��ͼƬ');
allPath=[pathName,fileName];


function edit1_Callback(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1 as text
%        str2double(get(hObject,'String')) returns contents of edit1 as a double


% --- Executes during object creation, after setting all properties.
function edit1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit2_Callback(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit2 as text
%        str2double(get(hObject,'String')) returns contents of edit2 as a double


% --- Executes during object creation, after setting all properties.
function edit2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit3_Callback(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
input = str2num(get(hObject,'String'));
if (isempty(input));
    set(hObject,'String','0')
end
% Hints: get(hObject,'String') returns contents of edit3 as text
%        str2double(get(hObject,'String')) returns contents of edit3 as a double


% --- Executes during object creation, after setting all properties.
function edit3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function axes1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to axes1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
set(hObject,'xTick',[]);
set(hObject,'yTick',[]);
set(hObject,'box','on');

% Hint: place code in OpeningFcn to populate axes1



function edit4_Callback(hObject, eventdata, handles)
% hObject    handle to edit4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit4 as text
%        str2double(get(hObject,'String')) returns contents of edit4 as a double


% --- Executes during object creation, after setting all properties.
function edit4_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit5_Callback(hObject, eventdata, handles)
% hObject    handle to edit5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit5 as text
%        str2double(get(hObject,'String')) returns contents of edit5 as a double


% --- Executes during object creation, after setting all properties.
function edit5_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object deletion, before destroying properties.
function text9_DeleteFcn(hObject, eventdata, handles)
% hObject    handle to text9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton4.
function pushbutton4_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global allPath
global K1

I=imread(allPath);
if size(I, 1) > 2000
    I = imresize(I, 0.2, 'bilinear');
end
K=imadjust(I,[0 0.6],[0 1]);  %����ͼ��Ҷ�
% figure(1);
% subplot(121); imshow(I); title('ԭʼͼ��');
% subplot(122); imshow(K); title('���ȵ�����ͼ��');

hsize = [3 3];
sigma = 0.5;
siz   = (hsize-1)/2;
std   = sigma;
[x,y] = meshgrid(-siz(2):siz(2),-siz(1):siz(1));
arg   = -(x.*x + y.*y)/(2*std*std);
h     = exp(arg);
h(h<eps*max(h(:))) = 0;

sumh = sum(h(:));
if sumh ~= 0,
    h  = h/sumh;
end;
G = imfilter(K, h, 'replicate');
% figure(2);
% subplot(121); imshow(K); title('ԭʼͼ��');
% subplot(122); imshow(G);    title('��˹ƽ���˲���ͼ��');

G=rgb2gray(G);
G1 = im2bw(G, graythresh(G));
G2 = ~G1;
% figure(3)
% subplot(121),imshow(G1);title('��ֵͼ��');
% subplot(122),imshow(G2);title('����ֵͼ��');

BW = G2;
[H,T,R]=hough(BW);
P=houghpeaks(H,4,'threshold',ceil(0.3*max(H(:))));
lines=houghlines(BW,T,R,P,'FillGap',50,'MinLength',7);%houghֱ��
max_len=0;
for i=1:length(lines)
    xy = [lines(i).point1; lines(i).point2]; %ֱ�ߵ�����
    len = norm(lines(i).point1-lines(i).point2); %ֱ�ߵĳ���
    Len(i)=len;
    if len>max_len
        max_len=len;
        xy_long=xy;
    end
    XY{i}=xy;
end
[Len,ind]=sort(Len(:),'descend');%ֱ�߳�������
for j=1:length(ind)
    XYn{j}=XY{ind(j)};
end
xy_long = XYn{1};
x=xy_long(:,1);
y=xy_long(:,2);
if abs(diff(x))<abs(diff(y))
    x=[mean(x);mean(x)];
else
    y = [0.7*y(1)+0.3*y(2); 0.3*y(1)+0.7*y(2)];
end
xy_long=[x y];

%ͼ��У��
x1 = xy_long(:, 1);
y1 = xy_long(:, 2);
%���߶�б��
K1 = -(y1(2)-y1(1))/(x1(2)-x1(1));
angle = atan(K1)*180/pi;
K1 = imrotate(K, -90-angle, 'bilinear');
BW1 = imrotate(BW, -90-angle, 'bilinear');
% figure(4)
% subplot(2, 2, 1); imshow(K, []); title('ԭͼ��', 'FontWeight', 'Bold');
% subplot(2, 2, 3); imshow(BW, []); title('ԭ����ֵͼ��', 'FontWeight', 'Bold');
% subplot(2, 2, 2); imshow(K1, []); title('У��ͼ��', 'FontWeight', 'Bold');
% subplot(2, 2, 4); imshow(BW1, []); title('У������ֵͼ��', 'FontWeight', 'Bold');
imshow(K1);
axes(handles.axes1);

%��̬ѧ�˲�
Bw2 = bwareaopen(BW1, round(0.005*numel(BW1)/85));
bws = sum(Bw2);
inds = find(bws>round(sum(Bw2(:))*0.005));
Loc1 = inds(1)-5;
Bw2(:, Loc1:end) = 0;
Bw2 = bwareaopen(Bw2, round(0.005*numel(BW1)/85));
% figure(5);
% subplot(1, 2, 1); imshow(BW1, []); title('У������ֵͼ��', 'FontWeight', 'Bold');
% subplot(1, 2, 2); imshow(Bw2, []); title('��̬ѧ�˲�ͼ��', 'FontWeight', 'Bold');

[H, T, R] = hough(Bw2);%HΪhough����TΪtheta��RΪrho
P = houghpeaks(H, 4, 'threshold', ceil(0.3*max(H(:))));
lines = houghlines(Bw2, T, R, P, 'FillGap', 50, 'MinLength', 7);
max_len = 0;
%����ֱ����Ϣ
for k = 1 : length(lines)
    xy = [lines(k).point1; lines(k).point2]; %ֱ�ߵ�����
    len = norm(lines(k).point1-lines(k).point2); %ֱ�ߵĳ���
    Len(k) = len;
    if len > max_len
        max_len = len;
        xy_long = xy;
    end
    XY{k} = xy; % �洢��Ϣ
end
[Len, ind] = sort(Len(:), 'descend'); % �����Ƚ�������indΪ��������
% ֱ����Ϣ����
for i = 1 : length(ind)
    XYn{i} = XY{ind(i)};%ind(i)Ϊ����������������λ��
end
xy_long = XYn{1};
x = xy_long(:, 1);
y = xy_long(:, 2);
if abs(diff(x)) < abs(diff(y))
    x = [mean(x); mean(x)];
else
    y = [0.7*y(1)+0.3*y(2); 0.3*y(1)+0.7*y(2)];
end
xy_long = [x y];

%����ָ�
for i = 1 : 2
    xy = XY{i}; %��i��ֱ��
    %ˮƽ��ֻ��עY���򼴿�
    XY{i} = [1 xy(1, 2); size(Bw2, 2) xy(2, 2)];%ֱ����Ϣ
    %Ϊ�˶�Ӧͼ�����أ�ȡ����
    ri(i) = round(mean([xy(1,2) xy(2,2)]));
end
%����ֱ�߷ֳ�����λ����
minr = min(ri);
maxr = max(ri);
Bw3= Bw2;
Bw4= Bw2;
%�ָ�����
%Bw3��Ӧ������
Bw3(1:minr+5, :) = 0;
Bw3(maxr-5:end, :) = 0;
%Bw4��Ӧ������
Bw4(minr-5:end, :) = 0;
Bw4(1:round(minr*0.5), :) = 0;
% figure(6)
% subplot(1, 3, 1);imshow(Bw2, []); title('У������ֵͼ��');
% subplot(1, 3, 2); imshow(Bw3, []); title('������ͼ��');
% subplot(1, 3, 3); imshow(Bw4, []); title('������ͼ��');

%������
[L1, num1] = bwlabel(Bw3);
%������������Ϣ
stats1 = regionprops(L1);
%���������
[L2, num2] = bwlabel(Bw4);
%������������Ϣ
%%regionprops()�ķ�����ϢĬ����Area��Centroid��BoundingBox
%AreaΪʵ����������
%CentroidΪ��Ч���������ڵ���������
%BoundingBox��ʽ[�������Ͻ����ꡭ������Ӧ������ȡ���]
%����[x,y,z,...,x_width,y_width,z_width,...]
stats2 = regionprops(L2);
%���������
Line1 = XYn{1};
Line2 = XYn{2};
%ȷ����������Ϣ
if mean(Line2(:, 2)) < mean(Line1(:, 2))
    Line1 = XYn{2};
    Line2 = XYn{1};
end
[r1, c1] = find(Bw3);%bw1�з���Ԫ�ص������±�
[r2, c2] = find(Bw4);
%��λֱ����Ϣ
Loc2 = min([min(c1), min(c2)])-5;
Line1 = [1 mean(Line1(:, 2)); size(K, 2) mean(Line1(:, 2))];
Line2 = [1 mean(Line2(:, 2)); size(K, 2) mean(Line2(:, 2))];
Line3 = [Loc2 1; Loc2 size(K, 1)];
Line4 = [Loc1 1; Loc1 size(K, 1)];
%ֱ������
Line{1} = Line1;
Line{2} = Line2;
Line{3} = Line3;
Line{4} = Line4;

[Dom,Aom,Answer,Bn]=Imageanalysis(stats1,stats2,Line,K1,0);

%%�Աȴ˴��⿨�����׼�𰸶ԱȼƷ�
% ��ȷ�򷵻ء���ϲ�㣡������ͨ���򷵻ء���ͨ����
% ���������
% Answer������ǰ�Ծ���
% pass_scores����������
% ���������
% pass����ͨ�����
filename = 'StanderAnswers.xls';
%��ȡ����׼�𰸵�excel�ļ�,��˳����ţ��𰸣���ֵ
[num,txt,raw] = xlsread(filename);
%��excel�ļ�����ת��Ϊ����
standerdAnswers = raw(2:length(raw),1:3);
%��ʼ��ѧ�����𰸾���
pass_scores=str2num(get(handles.edit3,'String'));

stuAnswer = cell(105,3);
for i = 1:length(Answer)
    stuAnswer{i,1} = Answer(i).no;
    stuAnswer{i,2} = Answer(i).aw;
    stuAnswer{i,3} = 0;
end
for i = 1:length(standerdAnswers)
    if stuAnswer{i,2} == standerdAnswers{i,2};
        stuAnswer{i,3} = standerdAnswers{i,3};
    else
        stuAnswer{i,3} = ~standerdAnswers{i,3};
    end
end
sum_scores = 0;
for i = 1:length(stuAnswer)
    sum_scores = sum_scores + stuAnswer{i,3};
end
if sum_scores >= pass_scores
    pass = 'ͨ��';
else
    pass = '��ͨ��';
end

stuNum_befor = Bn(2).result';
if ~isempty(stuNum_befor)
    for inum = 1 : length(stuNum_befor(1,:))
        tips(1,inum) = num2str(stuNum_befor(1,inum));
    end
else
    tips = 'ѧ��δ�ҵ���';
end

[stuNum,studentInfo] = WriteInExcel( Bn ,sum_scores,pass,5);
% %�����⿨ͼƬת�浽results�ļ���
set(handles.edit2,'String',pass);
set(handles.edit1,'String',num2str(stuNum));
set(handles.edit4,'String',num2str(sum_scores));
set(handles.edit5,'String',Bn(3).result);

Write_Results(K1,stuNum);

%2022.7.5 JIAQIGUO


% --- Executes on button press in pushbutton5.
function pushbutton5_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton6.
function pushbutton6_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global K1
figure(1);
imshow(K1);title('���⿨');
